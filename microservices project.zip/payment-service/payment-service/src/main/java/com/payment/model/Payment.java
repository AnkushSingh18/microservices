package com.payment.model;

public class Payment {
	private String name;
	private Long amount;
	private Long productId;
	
	public Payment(String name, Long amount, Long productId) {
		super();
		this.name = name;
		this.amount = amount;
		this.productId = productId;
	}

	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getAmount() {
		return amount;
	}

	public void setAmount(Long amount) {
		this.amount = amount;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}
	
	

}
