package com.payment.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.payment.model.Payment;

@Service
public class PaymentServiceImpl implements PaymentService{
	List<Payment> list = List.of(
			new Payment("ANK",15000L,111L)
			);

	@Override
	public List<Payment> getpayOfProduct(Long productId) {
		return list.stream().filter(pay -> pay.getProductId().equals(productId)).collect(Collectors.toList());
	}
	

}
