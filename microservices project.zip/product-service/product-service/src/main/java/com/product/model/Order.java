package com.product.model;

public class Order {
	private Long orderId;
	private String orderName;
	private Long orderCost;
	private Long productId;
	
	public Order(Long orderId, String orderName, Long orderCost, Long productId) {
		super();
		this.orderId = orderId;
		this.orderName = orderName;
		this.orderCost = orderCost;
		this.productId = productId;
	}

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getOrderName() {
		return orderName;
	}

	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}

	public Long getOrderCost() {
		return orderCost;
	}

	public void setOrderCost(Long orderCost) {
		this.orderCost = orderCost;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}
	
	
	

}
