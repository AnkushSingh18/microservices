package com.product.model;

import java.util.ArrayList;
import java.util.List;

public class Product {
	private String productName;
	private Long productId;
	private Long productCost;
	
	List<Order> orders = new ArrayList<>();
	List<Payment> pay = new ArrayList<>();

	public Product(String productName, Long productId, Long productCost, List<Order> orders, List<Payment> pay) {
		super();
		this.productName = productName;
		this.productId = productId;
		this.productCost = productCost;
		this.orders = orders;
		this.pay = pay;
	}

	public Product(String productName, Long productId, Long productCost) {
		super();
		this.productName = productName;
		this.productId = productId;
		this.productCost = productCost;
	}

	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getProductCost() {
		return productCost;
	}

	public void setProductCost(Long productCost) {
		this.productCost = productCost;
	}

	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

	public List<Payment> getPay() {
		return pay;
	}

	public void setPay(List<Payment> pay) {
		this.pay = pay;
	}

	public void setpayment(List pay2) {
		// TODO Auto-generated method stub
		
	}
	
	

	

}
