package com.product.service;

import com.product.model.Product;

public interface ProductService {
	
	public Product getProduct(Long id);

}
