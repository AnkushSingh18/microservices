package com.product.service;

import java.util.List;
import org.springframework.stereotype.Service;

import com.product.model.Product;

@Service
public class ProductServiceImpl implements ProductService {
	

    List<Product> list = List.of(
    		new Product("Smartphone",111L, 15000L),
    		new Product("Keyboard",5786438L, 2000L),
    		new Product("Mouse",97774536L, 500L)
    		
    );

    @Override
    public Product getProduct(Long id) {
        return list.stream().filter(product -> product.getProductId().equals(id)).findAny().orElse(null);
    }

}
