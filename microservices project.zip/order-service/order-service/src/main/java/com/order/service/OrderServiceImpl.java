package com.order.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.order.model.Order;

@Service
public class OrderServiceImpl implements OrderService {
	
	List<Order> list = List.of(
			new Order(1L,"ANK",15000L,111L),
			new Order(2L,"ANK",2000L,5786438L),
			new Order(3L,"ANK",500L,97774536L)
			);

	@Override
	public List<Order> getOrdersOfProduct(Long productId) {
		 return list.stream().filter(order -> order.getProductId().equals(productId)).collect(Collectors.toList());
	}
	
	

}
