package com.order.service;

import java.util.List;
import com.order.model.Order;

public interface OrderService {
	
	public List<Order> getOrdersOfProduct(Long productId);

}
